package com.example.camerabooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamerabookingApplicationTests {

	@Test
	void contextLoads() {
	}

}

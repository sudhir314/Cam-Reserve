package com.example.camerabooking.model;


public enum EventType {
    WEDDING,
    ANNIVERSARY,
    BIRTHDAY
}

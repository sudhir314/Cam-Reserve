package com.example.camerabooking.model;

public enum BookingStatus {
    PENDING,
    APPROVED,
    REJECTED
}

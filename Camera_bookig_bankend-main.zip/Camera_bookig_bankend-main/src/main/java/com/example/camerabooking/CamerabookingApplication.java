package com.example.camerabooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamerabookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamerabookingApplication.class, args);
	}

}
